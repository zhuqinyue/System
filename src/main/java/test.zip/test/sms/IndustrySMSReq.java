package test.sms;

import java.io.Serializable;

/**
 * @program: twbpm
 * @description: 报文体，业务参数
 * @author: Tangls
 * @create: 2021-06-23 14:45
 **/
public class IndustrySMSReq  implements Serializable {
    /**
     * 用户中心系统的账号，多个逗号(,)分隔上限100个，超出部分自动抛弃与strmobileNumber互斥，必选其
     */
    private String uId;
    /**
     * 消息类型9  短信32 随沃行日程提醒5  钉钉工作通知6  邮件
     */
    private String msgType="9";
    /**
     *授权ID
     */
    private String appId;
    /**
     * 秘钥
     */
    private String appSecret;
    /**
     * 接收人手机号，多个逗号(,)分隔上限100个，超出部分自动抛弃与uId互斥，必选其一
     */
    private String strmobileNumber;
    /**
     * 是否开启加密传输-true开启
     */
    private String cip="true";
    /**
     * 内容(2000)
     */
    private String strContent;

    public IndustrySMSReq(String msgType, String appId, String appSecret, String strmobileNumber, String cip, String strContent) {
        this.msgType = msgType;
        this.appId = appId;
        this.appSecret = appSecret;
        this.strmobileNumber = strmobileNumber;
        this.cip = cip;
        this.strContent = strContent;
    }

    public String getuId() {
        return uId;
    }

    public void setuId(String uId) {
        this.uId = uId;
    }

    public String getMsgType() {
        return msgType;
    }

    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public String getStrmobileNumber() {
        return strmobileNumber;
    }

    public void setStrmobileNumber(String strmobileNumber) {
        this.strmobileNumber = strmobileNumber;
    }

    public String getCip() {
        return cip;
    }

    public void setCip(String cip) {
        this.cip = cip;
    }

    public String getStrContent() {
        return strContent;
    }

    public void setStrContent(String strContent) {
        this.strContent = strContent;
    }
}
