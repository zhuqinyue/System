package test.sms;

import java.io.Serializable;

/**
 * @program: twbpm
 * @description: 报文头，系统参数
 * @author: Tangls
 * @create: 2021-06-23 14:46
 **/
public class UniBssHead implements Serializable {
    private String APP_ID;
    private String TIMESTAMP;
    private String TRANS_ID;
    private String TOKEN;

    public UniBssHead(String APP_ID, String TIMESTAMP, String TRANS_ID, String TOKEN) {
        this.APP_ID = APP_ID;
        this.TIMESTAMP = TIMESTAMP;
        this.TRANS_ID = TRANS_ID;
        this.TOKEN = TOKEN;
    }

    public String getAPP_ID() {
        return APP_ID;
    }

    public void setAPP_ID(String APP_ID) {
        this.APP_ID = APP_ID;
    }

    public String getTIMESTAMP() {
        return TIMESTAMP;
    }

    public void setTIMESTAMP(String TIMESTAMP) {
        this.TIMESTAMP = TIMESTAMP;
    }

    public String getTRANS_ID() {
        return TRANS_ID;
    }

    public void setTRANS_ID(String TRANS_ID) {
        this.TRANS_ID = TRANS_ID;
    }

    public String getTOKEN() {
        return TOKEN;
    }

    public void setTOKEN(String TOKEN) {
        this.TOKEN = TOKEN;
    }
}
