package test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;


import org.apache.commons.lang3.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicNameValuePair;
import test.sms.IndustrySMSReq;
import test.utils.AESUtils;
import test.utils.HttpClientHelper;
import test.utils.HttpHelper;
import test.utils.SignHelper;

import java.text.SimpleDateFormat;
import java.util.*;

import static java.nio.charset.StandardCharsets.UTF_8;

/**
 * @program: twbpm
 * @description: 短信发送实现类
 * @author: Tangls
 * @create: 2021-06-23 10:23
 **/
public class SMSProcessServiceImp{
    /**
     * 天擎鉴权
     */
    public static final String TQ_APPID ="";

    //天擎鉴权秘钥

      public static final String TQ_APPSECRET="";

    /**
     * 消息中心
     */
    //测试环境
      public static final String SMS_URL ="http://10.124.150.230:8000/api/MDomain/notificationCenter/IndustrySMS/v1";
    //生产
    // public static final String SMS_URL ="http://10.245.50.26:8000/api/MDomain/notificationCenter/IndustrySMS/v1";
    /**
     * 测试消息中心appId
     */


    /**
     * 生产消息中心appId
     */

    public static final String SMS_APPID ="";
    /**
     * 生产消息中心秘钥
     */

   public static final String SMS_APPSECRET="";



    public void checkToken(Map<String, Object> param) {
    }


    public String processMessage(Map<String,Object> m) throws Exception {
        String mobile = String.valueOf(m.get("Mobile"));
        String msgContext = String.valueOf(m.get("MsgContext"));
        if(StringUtils.isAnyBlank(mobile,msgContext)){
            return "Mobile和MsgContext不能为空";
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss SSS");
        String timeStamp = sdf.format(new Date());
        int randomNum= (int)((Math.random()*9+1)*100000);
        String transId =  timeStamp.replaceAll("\\:","").replaceAll("-","").replaceAll(" ","");
        //系统参数
        List<NameValuePair> ps = new ArrayList<NameValuePair>(25);
        p(ps, "APP_ID", TQ_APPID);//appID
        p(ps, "TIMESTAMP", timeStamp);//当前的系统时间戳，单位为毫秒，格式为“yyyy-MM-dd hh:mm:ss SSS”；例如："2018-05-10 15:05:58 174"
        p(ps, "TRANS_ID", transId.trim()+randomNum);// 根据上述时间戳和随机数生成，生成的长度为23的字符串，格式为 ：yyyyMMddhhmmssSSS+6位随机数。例如：“20180510150558174549793”
        String token =  SignHelper.buildSign(ps, TQ_APPSECRET);
        Map<String,Object> header =  new HashMap<String,Object>();
        header.put("APP_ID",TQ_APPID);
        header.put("TIMESTAMP",timeStamp);
        header.put("TRANS_ID",transId.trim()+randomNum);
        header.put("TOKEN",token);

        //业务参数
        Map<String,Object> body =  new HashMap<String,Object>();
        IndustrySMSReq industrysmsreq = new IndustrySMSReq(AESUtils.encrypt("9"),
                AESUtils.encrypt(SMS_APPID),AESUtils.encrypt(SMS_APPSECRET),AESUtils.encrypt(mobile),
                AESUtils.encrypt("true"),
                AESUtils.encrypt(msgContext));
        body.put("INDUSTRY_S_M_S_REQ",industrysmsreq);

        //其它参数
        Map<String,String> other= new HashMap<String,String>();
        other.put("MEDIA_INFO","");
        //全部参数
        Map<String,Object> param =  new HashMap<String,Object>();
        param.put("UNI_BSS_HEAD",header);
        param.put("UNI_BSS_BODY",body);
        param.put("UNI_BSS_ATTACHED",other);
        try {
            HttpPost httpPost = new HttpPost(SMS_URL);
            httpPost.setHeader("Content-Type","application/json; charset=UTF-8");
            httpPost.setHeader("Accept","application/json");
            httpPost.setHeader("Accept-Encoding","");
            httpPost.setEntity(new StringEntity(JSON.toJSONString(param), UTF_8));
            HttpClientHelper.init();
            String res = HttpHelper.getContentAsString(httpPost, 10000, UTF_8);
            System.out.println(res);
            return  res;
        }catch (Exception e){
            e.printStackTrace();
        }
        return "0";
    }


    public void init(Properties var1) {

    }


    public void processDeptMessage(Map<String, Object> param) throws Exception {

    }

    public static void  p(List<NameValuePair> ps, String name, java.lang.Object value) {
        ps.add(new BasicNameValuePair(name, value.toString()));
    }

    public static void main(String[] args) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss SSS");
        String timeStamp = sdf.format(new Date());
        int randomNum= (int)((Math.random()*9+1)*100000);
        String transId =  timeStamp.replaceAll("\\:","").replaceAll("-","").replaceAll(" ","");
        //系统参数
        List<NameValuePair> ps = new ArrayList<NameValuePair>(25);
        p(ps, "APP_ID", TQ_APPID);//appID
        p(ps, "TIMESTAMP", timeStamp);//当前的系统时间戳，单位为毫秒，格式为“yyyy-MM-dd hh:mm:ss SSS”；例如："2018-05-10 15:05:58 174"
        p(ps, "TRANS_ID", transId.trim()+randomNum);// 根据上述时间戳和随机数生成，生成的长度为23的字符串，格式为 ：yyyyMMddhhmmssSSS+6位随机数。例如：“20180510150558174549793”
        String token =  SignHelper.buildSign(ps, TQ_APPSECRET);
        //业务参数
        IndustrySMSReq industrysmsreq = null;
        try {
            industrysmsreq = new IndustrySMSReq(AESUtils.encrypt("9"),
                    AESUtils.encrypt(SMS_APPID),AESUtils.encrypt(SMS_APPSECRET),AESUtils.encrypt("18510670600,"),
                    AESUtils.encrypt("true"),
                    AESUtils.encrypt("你好，zhuqinyue"));
        } catch (Exception e) {
            e.printStackTrace();
        }

        Map<String,Object> param =  new HashMap<String,Object>();

        Map<String,Object> header =  new HashMap<String,Object>();
        header.put("APP_ID",TQ_APPID);
        header.put("TIMESTAMP",timeStamp);
        header.put("TRANS_ID",transId.trim()+randomNum);
        header.put("TOKEN",token);

        Map<String,Object> body =  new HashMap<String,Object>();
        body.put("INDUSTRY_S_M_S_REQ".toUpperCase(),industrysmsreq);
        param.put("UNI_BSS_HEAD",header);
        param.put("UNI_BSS_BODY",body);

        Map<String,String> body2= new HashMap<String,String>();
        body2.put("MEDIA_INFO","");

        param.put("UNI_BSS_ATTACHED",body2);

        System.out.println(JSON.toJSONString(param));
        try {
            HttpPost httpPost = new HttpPost(SMS_URL);
            httpPost.setHeader("Content-Type","application/json; charset=UTF-8");
            httpPost.setHeader("Accept","application/json");
            httpPost.setHeader("Accept-Encoding","");
            httpPost.setEntity(new StringEntity(JSON.toJSONString(param), UTF_8));
            HttpClientHelper.init();
            String resJson = HttpHelper.getContentAsString(httpPost, 10000, UTF_8);
            System.out.println("resJson"+resJson);

            JSONObject json  = JSON.parseObject(resJson);
            Map<String,Object> res  = (Map<String, Object>) json.get("UNI_BSS_BODY");
            Map<String,Object> res1 =  (Map<String, Object>) res.get("INDUSTRY_S_M_S_RSP");
            String  code  =  String.valueOf(res1.get("code"));

            Map<String,Object> res2 =  (Map<String, Object>) json.get("UNI_BSS_HEAD");
            String  respCode  =  String.valueOf(res2.get("RESP_CODE"));
            //200成功
            if("200".equals(code.trim()) && "00000".equals(respCode.trim())){
                System.out.println("1");
            }else {
                System.out.println("0");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
