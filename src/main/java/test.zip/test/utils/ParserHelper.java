package test.utils;

import org.apache.commons.io.IOUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

/**
 * 解析类
 * @author tang
 */
public abstract class ParserHelper {

    private static Pattern contentTypePattern = Pattern.compile("\\w+/[^;]+;[ ]*charset=(.*)");

    private ParserHelper() {
    }

    public static Charset analysisCharset(HttpEntity entity) throws IOException {
        String charset = null;
        Header contentType = entity.getContentType();
        if (contentType != null) {
            Matcher matcher = contentTypePattern.matcher(contentType.getValue());
            if (matcher.find()) {
                charset = matcher.group(1);
            }
        }
        if ("gb2312".equalsIgnoreCase(charset)) {
            charset = "GBK";
        }
        return charset == null ? null : Charset.forName(charset);
    }

    public static ByteArrayOutputStream getContentAsBytes(HttpEntity entity) throws IOException {
        InputStream in = entity.getContent();
        long length = entity.getContentLength();
        ByteArrayOutputStream out = new ByteArrayOutputStream(length < 0 ? 1024 : (int) length);
        IOUtils.copy(in, out);
        return out;
    }

    public static Reader getContentReader(HttpEntity entity, Charset defaultCharset) throws IOException {
        Charset charset = analysisCharset(entity);
        InputStream in = entity.getContent();
        Header contentEncoding = entity.getContentEncoding();
        if (contentEncoding != null && entity.getContentLength() != 0
                && "gzip".equalsIgnoreCase(contentEncoding.getValue())) {
            in = new GZIPInputStream(in);
        }
        return new InputStreamReader(in, charset == null ? defaultCharset : charset);
    }

    public static Reader getContentReader(HttpEntity entity) throws IOException {
        return getContentReader(entity, StandardCharsets.UTF_8);
    }

    public static String getContentAsString(HttpEntity entity) throws IOException {
        return IOUtils.toString(getContentReader(entity));
    }

    public static String getContentAsString(HttpEntity entity, Charset defaultCharset) throws IOException {
        return IOUtils.toString(getContentReader(entity, defaultCharset));
    }

}
