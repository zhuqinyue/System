package test.utils;

import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.ConnectionConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.config.SocketConfig;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;

public class HttpClientHelper {

    private static BasicCookieStore COOKIE_STORE;
    private static CloseableHttpClient client;

    private HttpClientHelper() {
    }

    public static void init() {
        PoolingHttpClientConnectionManager cm;
        try {
            SSLContextBuilder sslb = SSLContexts.custom();
            //添加证书
//            for (WeixinID wx : cfg.wxid().values()) {
//                char[] mch_id = wx.mch_id.toCharArray();
//                KeyStore keyStore = KeyStore.getInstance("PKCS12");
//                try (InputStream instream = Thread.currentThread().getContextClassLoader().getResourceAsStream(wx.apiclient_cert)) {
//                    keyStore.load(instream, mch_id);
//                }
//                sslb.loadKeyMaterial(keyStore, mch_id);
//            }

            SSLContext sslContext = sslb.build();
            HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
            SSLConnectionSocketFactory sf = new SSLConnectionSocketFactory(sslContext);

            Registry<ConnectionSocketFactory> r = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", PlainConnectionSocketFactory.INSTANCE).register("https", sf).build();
            cm = new PoolingHttpClientConnectionManager(r);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        HttpClientBuilder builder = HttpClientBuilder.create();
        cm.setDefaultMaxPerRoute(50000);
        cm.setMaxTotal(10000000);

        ConnectionConfig.Builder ccb = ConnectionConfig.copy(ConnectionConfig.DEFAULT);
        ccb.setBufferSize(8192);
        cm.setDefaultConnectionConfig(ccb.build());

        SocketConfig.Builder scb = SocketConfig.copy(SocketConfig.DEFAULT);
     //   scb.setRcvBufSize(8192);
     //   scb.setSndBufSize(8192);
     //   scb.setSoTimeout(5000);
        cm.setDefaultSocketConfig(scb.build());

        builder.setUserAgent("Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.5)");

        builder.setConnectionManager(cm);

        RequestConfig req_cfg = RequestConfig.custom().setConnectTimeout(1000).setSocketTimeout(5000).build();
        builder.setDefaultRequestConfig(req_cfg);

        COOKIE_STORE = new BasicCookieStore();
        builder.setDefaultCookieStore(COOKIE_STORE);

        client = builder.build();

    }

    /**
     * 添加全局cookie
     *
     * @param cookie
     */
    public static void addCookie(Cookie cookie) {
        COOKIE_STORE.addCookie(cookie);
    }

    public static CookieStore getCookieStore() {
        return COOKIE_STORE;
    }

    public static HttpClient getClient() {
        return client;
    }

}