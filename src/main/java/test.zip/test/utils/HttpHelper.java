package test.utils;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.util.EntityUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;

/**
 * Http helper
 *
 * @author wuwei
 * @since 1.0.9
 */
public abstract class HttpHelper {

    private HttpHelper() {
    }

    public static String getContentAsString(String uri, int soTimeout) {
        return getContentAsString(new HttpGet(uri), soTimeout);
    }

    public static String getContentAsString(String uri, int soTimeout, Charset charset) {
        return getContentAsString(new HttpGet(uri), soTimeout, charset);
    }

    public static String getContentAsString(HttpRequestBase req, int soTimeout) {
        return getContentAsString(req, soTimeout, null);
    }

    public static String getContentAsString(HttpRequestBase req, int soTimeout, Charset charset) {
        HttpEntity entity = null;
        String t = null;
        try {
            req.setConfig(RequestConfig.custom().setSocketTimeout(soTimeout).build());
            HttpResponse resp = HttpClientHelper.getClient().execute(req);
            entity = resp.getEntity();
            if (entity != null) {
                if (charset == null) {
                    t = ParserHelper.getContentAsString(entity);
                } else {
                    t = ParserHelper.getContentAsString(entity, charset);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            EntityUtils.consumeQuietly(entity);
        }
        return t;
    }

    public static ByteArrayOutputStream getContentAsBytes(String uri, int soTimeout) {
        return getContentAsBytes(new HttpGet(uri), soTimeout);
    }

    public static ByteArrayOutputStream getContentAsBytes(HttpRequestBase req, int soTimeout) {
        HttpEntity entity = null;
        ByteArrayOutputStream t = null;
        try {
            req.setConfig(RequestConfig.custom().setSocketTimeout(soTimeout).build());
            HttpResponse resp = HttpClientHelper.getClient().execute(req);
            entity = resp.getEntity();
            if (entity != null) {
                t = ParserHelper.getContentAsBytes(entity);
            }
        } catch (IOException e) {
           e.printStackTrace();
        } finally {
            EntityUtils.consumeQuietly(entity);
        }
        return t;
    }

}
