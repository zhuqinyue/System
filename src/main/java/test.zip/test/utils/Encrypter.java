package test.utils;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class Encrypter {

    public final static String md5(String data) {
        return md5(data, StandardCharsets.UTF_8);
    }

    public final static String md5(String data, Charset charset) {
        return byte2hex(encrypt("MD5", data.getBytes(charset)));
    }

    public final static String sha(String data) {
        return sha(data, StandardCharsets.UTF_8);
    }

    public final static String sha(String data, Charset charset) {
        return byte2hex(encrypt("SHA", data.getBytes(charset)));
    }

    public final static String sha1(String data) {
        return sha1(data, StandardCharsets.UTF_8);
    }

    public final static String sha1(String data, Charset charset) {
        return byte2hex(encrypt("SHA-1", data.getBytes(charset)));
    }

    public static byte[] encrypt(String algorithm, byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance(algorithm);
            return md.digest(data);
        } catch (Exception gse) {
            throw new RuntimeException(gse);
        }
    }

    public static String hamc(String data, String secret) {
        return hamc(data, secret, StandardCharsets.UTF_8);
    }

    public static String hamc(String data, String secret, Charset charset) {
        try {
            SecretKey secretKey = new SecretKeySpec(secret.getBytes(charset), "HmacMD5");
            Mac mac = Mac.getInstance(secretKey.getAlgorithm());
            mac.init(secretKey);
            byte[] bytes = mac.doFinal(data.getBytes(charset));
            return byte2hex(bytes);
        } catch (Exception gse) {
            throw new RuntimeException(gse);
        }
    }

    public static String byte2hex(byte[] bytes) {
        StringBuilder sign = new StringBuilder(bytes.length * 2);
        for (int i = 0; i < bytes.length; i++) {
            String hex = Integer.toHexString(bytes[i] & 0xFF);
            if (hex.length() == 1) {
                sign.append("0");
            }
            sign.append(hex);
        }
        return sign.toString();
    }

    public static String md5(String s, String charset) {
		return MD5(s, charset);
	}

    private static String MD5(String s, String charset) {
        char hexDigits[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                'a', 'b', 'c', 'd', 'e', 'f' };
        try {
            byte[] strTemp = s.getBytes(charset);
            MessageDigest mdTemp = MessageDigest.getInstance("MD5");
            mdTemp.update(strTemp);
            byte[] md = mdTemp.digest();
            int j = md.length;
            char str[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                str[k++] = hexDigits[byte0 >>> 4 & 0xf];
                str[k++] = hexDigits[byte0 & 0xf];
            }
            return new String(str);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     *
     * @param plainText
     *            明文
     * @return 32位密文
     */
    public static String encryption(String plainText) {
        String re_md5 = new String();
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(plainText.getBytes());
            byte b[] = md.digest();

            int i;

            StringBuffer buf = new StringBuffer("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0) {
                    i += 256;
                }
                if (i < 16) {
                    buf.append("0");
                }
                buf.append(Integer.toHexString(i));
            }

            re_md5 = buf.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return re_md5;
    }
}