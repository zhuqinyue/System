package test.utils;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 * Created by tangls on 2016/6/28.
 */
public class SignHelper {

    public static boolean checkSign(HttpServletRequest req, String secrect) {
        List<NameValuePair> ps = new ArrayList<NameValuePair>(40);
        Enumeration<String> names = req.getParameterNames();
        while (names.hasMoreElements()) {
            String name = names.nextElement();
            if (name.equals("sign")) {
                continue;
            }
            p(ps, name, req.getParameter(name));
        }

        return buildSign(ps, secrect).equalsIgnoreCase(req.getParameter("sign"));
    }

    /**
     * build sign
     *
     * @param list params to sign
     * @return sign result
     */
    public static String buildSign(List<? extends NameValuePair> list, String secret) {
        if (list.isEmpty() || StringUtils.isEmpty(secret)) {
            throw new RuntimeException("invalid params");
        }
        StringBuilder buf = new StringBuilder(list.size() * 50 + secret.length());
//       jdk1.8
//       list.stream().filter(v -> v.getValue() != null && v.getValue().length() > 0)
//               .sorted(Comparator.comparing(NameValuePair::getName))
//                .forEach(v -> buf.append(v.getName()).append(v.getValue()));


        List<NameValuePair> tempList = new ArrayList<NameValuePair>();
        for (NameValuePair v: list){
             if(null!=v.getValue() && v.getValue().length()>0){
                 tempList.add(v);
             }
        }
        //进行排序
//        Collections.sort(tempList, new Comparator<NameValuePair>() {
// 
//            @Override
//            public int compare(NameValuePair o1, NameValuePair o2) {
//                // 升序
//                return o1.getName().compareTo(o2.getName());
//
//            }
//        });

        
        for (NameValuePair v: tempList) {
                buf.append(v.getName()).append(v.getValue());
        }
        buf.append(secret);
        return Encrypter.md5(buf.toString());
    }



    /**
     * build sign
     *
     * @param list params to sign
     * @return sign result
     */
    public static String buildSignByHMAC_SHA256(List<? extends NameValuePair> list, String secret) {
        if (list.isEmpty() || StringUtils.isEmpty(secret)) {
            throw new RuntimeException("invalid params");
        }
        StringBuilder buf = new StringBuilder(list.size() * 50 + secret.length());
//        list.stream().filter(v -> v.getValue() != null && v.getValue().length() > 0)
//                .sorted(Comparator.comparing(NameValuePair::getName))
//                .forEach(v -> buf.append(v.getName()).append('=').append(v.getValue()).append('&'));
//        buf.append("key=").append(secret);
//        list.sort(Comparator.comparing(NameValuePair::getName));
        //进行排序
//        Collections.sort(list, new Comparator<NameValuePair>() {
// 
//            @Override
//            public int compare(NameValuePair o1, NameValuePair o2) {
//                // 升序
//                return o1.getName().compareTo(o2.getName());
//            }
//        });
        
        for (NameValuePair v: list) {
             if(v.getValue() != null && v.getValue().length() > 0){
                 buf.append(v.getName()).append('=').append(v.getValue()).append('&');
             }
        }
        buf.append("key=").append(secret);
       return sha256_HMAC(buf.toString(),secret).toUpperCase();
    }




    public static void p(List<NameValuePair> ps, String name, Object value) {
        ps.add(new BasicNameValuePair(name, value.toString()));
    }

    /**
     * 将加密后的字节数组转换成字符串
     *
     * @param b 字节数组
     * @return 字符串
     */
    public  static String byteArrayToHexString(byte[] b) {
        StringBuilder hs = new StringBuilder();
        String stmp;
        for (int n = 0; b!=null && n < b.length; n++) {
            stmp = Integer.toHexString(b[n] & 0XFF);
            if (stmp.length() == 1) {
                hs.append('0');
            }
            hs.append(stmp);
        }
        return hs.toString().toLowerCase();
    }
    /**
     * sha256_HMAC加密
     * @param message 消息
     * @param secret  秘钥
     * @return 加密后字符串
     */
    public static String sha256_HMAC(String message, String secret) {
        String hash = "";
        try {
            Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
            SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
            sha256_HMAC.init(secret_key);
            byte[] bytes = sha256_HMAC.doFinal(message.getBytes());
            hash = byteArrayToHexString(bytes);
        } catch (Exception e) {
            System.out.println("Error HmacSHA256 ===========" + e.getMessage());
        }
        return hash;
    }
}
